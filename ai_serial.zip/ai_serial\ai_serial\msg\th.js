Blockly.Msg.ai_serial_TEXT_TITLE   = "เอไอ ซีเรียล";
Blockly.Msg.ai_serial_TEXT_TOOLTIP = "รับค่าผลลัพธ์จากโมเดล AI ผ่านสาย USB Serial";
Blockly.Msg.ai_serial_TEXT_HELPURL = "";
