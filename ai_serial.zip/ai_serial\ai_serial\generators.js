Blockly.JavaScript['ai_serial.data'] = function (block) {
  return [`DEV_IO.ai_serial().get_label()`, Blockly.JavaScript.ORDER_ATOMIC];
};

Blockly.JavaScript['ai_serial.is_detected'] = function (block) {
  var label = block.getFieldValue('LABEL') || '';
  return [`DEV_IO.ai_serial().is_detected("${label}")`, Blockly.JavaScript.ORDER_ATOMIC];
};

Blockly.JavaScript['ai_serial.has_new'] = function (block) {
  return [`DEV_IO.ai_serial().has_new()`, Blockly.JavaScript.ORDER_ATOMIC];
};
