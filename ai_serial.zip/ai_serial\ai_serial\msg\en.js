Blockly.Msg.ai_serial_TEXT_TITLE   = "AI Serial";
Blockly.Msg.ai_serial_TEXT_TOOLTIP = "AI Serial Teachable Machine";
Blockly.Msg.ai_serial_TEXT_HELPURL = "";
