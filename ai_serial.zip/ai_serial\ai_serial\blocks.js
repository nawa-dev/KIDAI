var ai_serial_color_hue = 190;

Blockly.Blocks["ai_serial.data"] = {
    init: function() {
        this.appendDummyInput()
            .appendField("AI latest label");

        this.setOutput(true, 'String');
        this.setInputsInline(false);
        this.setColour(ai_serial_color_hue);
        this.setTooltip("latest label from AI");
        this.setHelpUrl("");
    }
};

Blockly.Blocks["ai_serial.is_detected"] = {
    init: function() {
        this.appendDummyInput()
            .appendField("AI detected")
            .appendField(new Blockly.FieldTextInput("person_a"), "LABEL");

        this.setOutput(true, 'Boolean');
        this.setInputsInline(false);
        this.setColour(ai_serial_color_hue);
        this.setTooltip("check if AI detected");
        this.setHelpUrl("");
    }
};

Blockly.Blocks["ai_serial.has_new"] = {
    init: function() {
        this.appendDummyInput()
            .appendField("AI has new data?");

        this.setOutput(true, 'Boolean');
        this.setInputsInline(false);
        this.setColour(ai_serial_color_hue);
        this.setTooltip("has new data");
        this.setHelpUrl("");
    }
};
