#ifndef __ai_serial_CPP__
#define __ai_serial_CPP__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "driver/uart.h"
#include "kidbright32.h"
#include "ai_serial.h"

static char _ai_latest_label[64] = "AI_READY";
static volatile bool _ai_has_new = false;
static volatile bool _uart_ready = false;

// Task pinned to Core 0 to handle UART0 teardown, re-install and reception.
// This is required because KidBright's app_main registered the UART0 ISR on Core 0.
// Calling esp_intr_free / uart_driver_delete from Core 0 cleanly unregisters the ISR
// without causing xRingbufferSendFromISR panics or infinite reboot loops.
static void ai_uart_core0_task(void *pvParameters) {
    // 1. Delete default UART driver on Core 0
    uart_driver_delete(UART_NUM_0);

    // 2. Configure and reinstall clean UART0 driver on Core 0
    uart_config_t uart_config;
    memset(&uart_config, 0, sizeof(uart_config));
    uart_config.baud_rate = 115200;
    uart_config.data_bits = UART_DATA_8_BITS;
    uart_config.parity = UART_PARITY_DISABLE;
    uart_config.stop_bits = UART_STOP_BITS_1;
    uart_config.flow_ctrl = UART_HW_FLOWCTRL_DISABLE;
    uart_param_config(UART_NUM_0, &uart_config);
    uart_set_pin(UART_NUM_0, 1, 3, -1, -1);
    uart_driver_install(UART_NUM_0, 256, 0, 0, NULL, 0);

    _uart_ready = true;

    // 3. Serial RX loop on Core 0
    char buf[64];
    int idx = 0;
    while (1) {
        uint8_t c;
        if (uart_read_bytes(UART_NUM_0, &c, 1, 10 / portTICK_RATE_MS) > 0) {
            if (c == '\n') {
                buf[idx] = '\0';
                if (idx > 0 && buf[idx - 1] == '\r') {
                    buf[idx - 1] = '\0';
                    idx--;
                }
                if (idx > 0) {
                    strncpy(_ai_latest_label, buf, sizeof(_ai_latest_label) - 1);
                    _ai_latest_label[sizeof(_ai_latest_label) - 1] = '\0';
                    _ai_has_new = true;
                    // Acknowledge received label to Web Serial
                    printf("OK:%s\n", _ai_latest_label);
                }
                idx = 0;
            } else if (c != '\r') {
                if (idx < (int)(sizeof(buf) - 1)) {
                    buf[idx++] = (char)c;
                } else {
                    idx = 0; // Prevent buffer overflow
                }
            }
        }
    }
}

ai_serial::ai_serial() {
    polling_ms = ai_serial_POLLING_MS;
}

void ai_serial::init(void) {
    initialized = true;
    error = false;

    // 1. Terminate KidBright's background "Uart Task" so it doesn't compete for UART0
    UBaseType_t num_tasks = uxTaskGetNumberOfTasks();
    TaskSnapshot_t *snapshots = (TaskSnapshot_t *)malloc(sizeof(TaskSnapshot_t) * (num_tasks + 10));
    if (snapshots != NULL) {
        UBaseType_t tcb_size = 0;
        UBaseType_t count = uxTaskGetSnapshotAll(snapshots, num_tasks + 10, &tcb_size);
        for (UBaseType_t i = 0; i < count; i++) {
            TaskHandle_t h = (TaskHandle_t)snapshots[i].pxTCB;
            if (h != NULL) {
                char *name = pcTaskGetTaskName(h);
                if (name != NULL && strcmp(name, "Uart Task") == 0) {
                    vTaskDelete(h);
                    break;
                }
            }
        }
        free(snapshots);
    }

    // Allow FreeRTOS scheduler to clean up deleted task
    vTaskDelay(20 / portTICK_RATE_MS);

    // 2. Launch Core 0 task to teardown, reinstall, and service UART0
    _uart_ready = false;
    xTaskCreatePinnedToCore(ai_uart_core0_task, "ai_uart_core0", 4096, NULL, 12, NULL, 0);

    // 3. Wait until Core 0 finishes UART0 setup
    while (!_uart_ready) {
        vTaskDelay(10 / portTICK_RATE_MS);
    }
}

int ai_serial::prop_count(void) {
    return 0;
}

bool ai_serial::prop_name(int index, char *name) {
    return false;
}

bool ai_serial::prop_unit(int index, char *unit) {
    return false;
}

bool ai_serial::prop_attr(int index, char *attr) {
    return false;
}

bool ai_serial::prop_read(int index, char *value) {
    return false;
}

bool ai_serial::prop_write(int index, char *value) {
    return false;
}

void ai_serial::process(Driver *drv) {
    // Handled asynchronously on Core 0
}

char* ai_serial::get_label(void) {
    // Yield CPU to FreeRTOS scheduler to prevent Task Watchdog timeout on CPU 1
    vTaskDelay(10 / portTICK_RATE_MS);
    return _ai_latest_label;
}

bool ai_serial::is_detected(const char* target) {
    vTaskDelay(10 / portTICK_RATE_MS);
    if (!target || _ai_latest_label[0] == '\0') {
        return false;
    }
    return (strcmp(_ai_latest_label, target) == 0);
}

bool ai_serial::has_new(void) {
    vTaskDelay(10 / portTICK_RATE_MS);
    if (_ai_has_new) {
        _ai_has_new = false;
        return true;
    }
    return false;
}

#endif
