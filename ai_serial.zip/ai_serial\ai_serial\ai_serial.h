#ifndef __ai_serial_H__
#define __ai_serial_H__

#include <string.h>
#include <stdlib.h>
#include "driver.h"
#include "device.h"

#define ai_serial_POLLING_MS         50

class ai_serial : public Device {
    private:

    public:
        // constructor
        ai_serial();
        // override
        void init(void);
        void process(Driver *drv);
        int prop_count(void);
        bool prop_name(int index, char *name);
        bool prop_unit(int index, char *unit);
        bool prop_attr(int index, char *attr);
        bool prop_read(int index, char *value);
        bool prop_write(int index, char *value);
        // method
        char* get_label(void);
        bool is_detected(const char* target);
        bool has_new(void);
};

#endif
